/* 
 * Author: Marco Arias
 * Created on January 31, 2016, 08:55 AM
 * Purpose: Tic-Tac-Toe
 */
 
//System Libraries
#include <iostream>
#include <cstdlib>
#include <fstream>
using namespace std;
 
//User Libraries
 
//Global Constant

//Function Prototypes
char matrix[3][3]={'1','2','3','4','5','6','7','8','9'};//the matrix rows and columns
char player='X';//used to toggle between players
char win();//Input the winning sequences
void draw();//Input the draw sequences
void input();//The player inputs their number to exchange as a letter
void tglPlyr();//Goes between players

//Execution Begins Here
  int main(int argc, char** argv) { 
//Declare and initialize variables
      ofstream myfile;
      myfile.open("newfile.txt");
      myfile<<"This file is for the Tic-Tac-Toe game!\n";
      myfile.close();
      int n=0;//The number of times The players have gone
      //Introduce Game
      cout<<"This is TIC-TAC-TOE, CSC5 style. To win, make a pattern of 3 \n"
              "of the same letters in a row. It is a 2 player game with the \n"
              "characters 'X' and 'O'. First player gets assigned 'X' and \n"
              "second player is assigned 'O'. If no patterns are made within \n"
              "9 attempts, it is a Cats Game or Draw. Enter a number 1-9 \n"
              "to replace it with your character. Ready, Set, Play!!\n";
    draw();{
        
           }
    while(1){
        n++;
        input();{
            
                }
        draw();{
        if (win()=='X'){
            cout<<"'X' Wins!!\n";
            break;
        }else if (win()=='O'){
            cout<<"'O' Wins!!\n";
            break;
        }else if (win()=='/' && n==9){
            cout<<"Cats Game! Nobody wins!"<<endl;
            break;             
         }
        
        tglPlyr();
        
      }
        
    } 
   //Exit stage 
    return 0;
}
//All functional prototypes are found here till the end of the code
void draw(){//Displays the rows and columns and makes it available to
    //enter an input.
 for (int row=0;row<3;row++){
            for(int col=0;col<3;col++){
                cout<<matrix[row][col]<<" ";
            }
            cout<<endl;
        }
    }
void input(){
        int a;
        cout<<"Player "<<player<<" is up! ";
        cin>>a;//User enters their move
        
 //Enter the users slot and if the slot is taken already, do not allow them
 // to use the space. "a" is the players input.     
    if (a==1){
        if (matrix[0][0]=='1')
            matrix[0][0]=player;
        else{
            cout<<"\nSlot taken. Try again\n"<<endl;
            input();
        }
    }
    else if (a==2){
        if (matrix[0][1]=='2')
            matrix[0][1]=player;
        else{
            cout<<"\nSlot taken. Try again\n"<<endl;
            input();
        }
    }
    else if (a == 3){
        if (matrix[0][2]=='3')
            matrix[0][2]=player;
        else{
            cout<<"\nSlot taken. Try again\n"<<endl;
            input();
        }
    }
    else if (a==4){
        if (matrix[1][0]=='4')
            matrix[1][0]=player;
        else{
            cout<<"\nSlot taken. Try again\n"<<endl;
            input();
        }
    }
    else if (a==5){
        if (matrix[1][1]=='5')
            matrix[1][1]=player;
        else{
            cout<<"\nSlot taken. Try again\n"<<endl;
            input();
        }
    }
    else if (a==6){
        if (matrix[1][2]=='6')
            matrix[1][2]=player;
        else{
            cout<<"\nSlot taken. Try again\n"<<endl;
            input();
        }
    }
    else if (a==7){
        if (matrix[2][0]=='7')
            matrix[2][0]=player;
        else{
            cout<<"\nSlot taken. Try again\n"<<endl;
            input();
        }
    }
    else if (a==8){
        if (matrix[2][1]=='8')
            matrix[2][1]=player;
        else{
            cout<<"\nSlot taken. Try again\n"<<endl;
            input();
        }
    }
    else if (a==9){
        if (matrix[2][2]=='9')
            matrix[2][2]=player;
        else{
            cout<<"\nSlot taken. Try again\n"<<endl;
            input();
        }
    }
}

//123456781.245389712346578912336548975465489765465487916548791326548697321654
//123654789     //This function toggles between players     321654654831465466
//123456781.245389712346578912336548975465489765465487916548791326548697321654

    void tglPlyr(){//Goes between players
        if(player=='X')
            player='O';
        else player='X';
    }
    //This function checks who has a match with the winning sequence
    char win(){//Winning sequence
        //Win for X
        if (matrix[0][0] =='X'&& matrix[0][1] =='X'&& matrix[0][2] =='X')//1
            return 'X';
        if (matrix[1][0] =='X'&& matrix[1][1] =='X'&& matrix[1][2] =='X')//2
            return 'X';
        if (matrix[2][0] =='X'&& matrix[2][1] =='X'&& matrix[2][2] =='X')//3
            return 'X';
        if (matrix[0][0] =='X'&& matrix[1][0] =='X'&& matrix[2][0] =='X')//4
            return 'X';
        
        if (matrix[0][1] =='X'&& matrix[1][1] =='X'&& matrix[2][1] =='X')//5
            return 'X';
        if (matrix[0][2] =='X'&& matrix[1][2] =='X'&& matrix[2][2] =='X')//6
            return 'X';
        //diagonals for reference
        //00 01 02
        //10 11 12
        //20 21 22
        //diagonal wins for X
        if (matrix[0][0] =='X'&& matrix[1][1] =='X'&& matrix[2][2] =='X')//7
            return 'X';
        if (matrix[2][0] =='X'&& matrix[1][1] =='X'&& matrix[0][2] =='X')//8
            return 'X';
        
       //Win for O
        if (matrix[0][0] =='O'&& matrix[0][1] =='O'&& matrix[0][2] =='O')//9
            return 'O';
        if (matrix[1][0] =='O'&& matrix[1][1] =='O'&& matrix[1][2] =='O')//10
            return 'O';
        if (matrix[2][0] =='O'&& matrix[2][1] =='O'&& matrix[2][2] =='O')//11
            return 'O';
        if (matrix[0][0] =='O'&& matrix[1][0] =='O'&& matrix[2][0] =='O')//12
            return 'O';
        
        if (matrix[0][1] =='O'&& matrix[1][1] =='O'&& matrix[2][1] =='O')//13
            return 'O';
        if (matrix[0][2] =='O'&& matrix[1][2] =='O'&& matrix[2][2] =='O')//14
            return 'O';
        //diagonals for reference
        //00 01 02
        //10 11 12
        //20 21 22
        //diagonal wins for O
        if (matrix[0][0] =='O'&& matrix[1][1] =='O'&& matrix[2][2] =='O')//15
            return 'O';
        if (matrix[2][0] =='O'&& matrix[1][1] =='O'&& matrix[0][2] =='O')//16
            return 'O';
        return '/';//End of game! Project 2 Version 1
    }
    