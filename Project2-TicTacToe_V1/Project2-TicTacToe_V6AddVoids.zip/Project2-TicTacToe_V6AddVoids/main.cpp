/* 
 * Author: Marco Arias
 * Created on January 31, 2016, 08:55 AM
 * Purpose: Tic-Tac-Toe
 */
 
//System Libraries
#include <iostream>
#include <cstdlib>
#include <fstream>
using namespace std;
 
//User Libraries
 
//Global Constant

//Function Prototypes
char TABLE[3][3]={'1','2','3','4','5','6','7','8','9'};//the TABLE rows & columns
char PLAYER='X';
int win();//Input the winning sequences
void draw(int,int);//Input the draw sequences
void input();//The PLAYER inputs their number to exchange as a letter
void tglPlyr();//Goes between PLAYERs

//Execution Begins Here
  int main(int argc, char** argv) { 
//Declare and initialize variables
      ofstream outFile;//Open the file to write in
      outFile.open("Project2.txt",ios::out);//Output file
      int n=0;//The number of times The players have gone
      int row;//The rows
      int col;//The columns
      //Introduce Game
      cout<<"This is TIC-TAC-TOE, CSC5 style. To win, make a pattern of 3 \n"
              "of the same letters in a row. It is a 2 PLAYER game with the \n"
              "characters 'X' and 'O'. First PLAYER gets assigned 'X' and \n"
              "second PLAYER is assigned 'O'. If no patterns are made within \n"
              "9 attempts, it is a Cats Game or Draw. Enter a number 1-9 \n"
              "to replace it with your character. Ready, Set, Play!!\n";
    draw(row,col);{
        
           }
   
    while(win()!='X' && win()!='O'){
        n++;
        input();{
            
                }
        draw(row,col);{
        if (win()=='X'){
            cout<<"'X' Wins!!\n";
            outFile<<"'X' Wins!!\n"<<endl;
        }else if (win()=='O'){
            cout<<"'O' Wins!!\n";
            outFile<<"'O' Wins!!\n"<<endl;
        }else if (win()=='/' && n==9){
            cout<<"Cats Game! Nobody wins!"<<endl; 
            outFile<<"Cats Game! Nobody wins!"<<endl;
         }
        
        tglPlyr();
       
      }  
    } 

    outFile.close();
   //Exit stage right
    return 0;
}
  
/*123456781.245389712346578912336548975465489765465487916548791326548697321654
 *                                                                           *
 *                      *Tell the program rows and columns*                  *
 *                                                                           *   
/*123456781.24538971234657891233654897546548976546548791654879132654869732164*/  
//All functional prototypes are found here till the end of the code
void draw(int row, int col){//Displays the rows and columns and makes it
    //available to enter an input.
 for (row=0;row<3;row++){
            for(col=0;col<3;col++){
                cout<<TABLE[row][col]<<" ";          
            }
            cout<<endl;
        }
    }

/*123456781.245389712346578912336548975465489765465487916548791326548697321654
 *                                                                           *
 *                      *This function reads the winning sequence*           *
 *                                                                           *   
/*123456781.24538971234657891233654897546548976546548791654879132654869732164*/
//Displays which player is next and if the slot is taken or not
void input(){
        
        int a;//The players input
        //Shows which player is up
        cout<<"Player "<<PLAYER<<" is up! ";
        cin>>a;//User enters their move
        
 //Enter the users slot and if the slot is taken already, do not allow them
 //to use the space. "a" is the PLAYERs input.     
    if (a==1){
        if (TABLE[0][0]=='1')
            TABLE[0][0]=PLAYER;
        else{
            cout<<"\nSlot taken. Try again\n"<<endl;
            input();
        }
    }
    else if (a==2){
        if (TABLE[0][1]=='2')
            TABLE[0][1]=PLAYER;
        else{
            cout<<"\nSlot taken. Try again\n"<<endl;
            input();
        }
    }
    else if (a==3){
        if (TABLE[0][2]=='3')
            TABLE[0][2]=PLAYER;
        else{
            cout<<"\nSlot taken. Try again\n"<<endl;
            input();
        }
    }
    else if (a==4){
        if (TABLE[1][0]=='4')
            TABLE[1][0]=PLAYER;
        else{
            cout<<"\nSlot taken. Try again\n"<<endl;
            input();
        }
    }
    else if (a==5){
        if (TABLE[1][1]=='5')
            TABLE[1][1]=PLAYER;
        else{
            cout<<"\nSlot taken. Try again\n"<<endl;
            input();
        }
    }
    else if (a==6){
        if (TABLE[1][2]=='6')
            TABLE[1][2]=PLAYER;
        else{
            cout<<"\nSlot taken. Try again\n"<<endl;
            input();
        }
    }
    else if (a==7){
        if (TABLE[2][0]=='7')
            TABLE[2][0]=PLAYER;
        else{
            cout<<"\nSlot taken. Try again\n"<<endl;
            input();
        }
    }
    else if (a==8){
        if (TABLE[2][1]=='8')
            TABLE[2][1]=PLAYER;
        else{
            cout<<"\nSlot taken. Try again\n"<<endl;
            input();
        }
    }
    else if (a==9){
        if (TABLE[2][2]=='9')
            TABLE[2][2]=PLAYER;
        else{
            cout<<"\nSlot taken. Try again\n"<<endl;
            input();
        }
    }
}

/*123456781.245389712346578912336548975465489765465487916548791326548697321654
 *                                                                           *
 *                         *This function toggles between PLAYERs*           *
 *                                                                           *   
/*123456781.24538971234657891233654897546548976546548791654879132654869732164*/

    void tglPlyr(){//Goes between PLAYERs
        
        if(PLAYER=='X')
            PLAYER='O';
            else PLAYER='X';
            
        
    }
/*123456781.245389712346578912336548975465489765465487916548791326548697321654
 *                                                                           *
 *                 *Checks who has a match with the winning sequence*        *
 *                                                                           *   
/*123456781.24538971234657891233654897546548976546548791654879132654869732164*/  
  
int win(){//Winning sequence
    //Win for X
    if (TABLE[0][0] =='X'&& TABLE[0][1] =='X'&& TABLE[0][2] =='X')//1
        return 'X';
    if (TABLE[1][0] =='X'&& TABLE[1][1] =='X'&& TABLE[1][2] =='X')//2
        return 'X';
    if (TABLE[2][0] =='X'&& TABLE[2][1] =='X'&& TABLE[2][2] =='X')//3
        return 'X';
    if (TABLE[0][0] =='X'&& TABLE[1][0] =='X'&& TABLE[2][0] =='X')//4
        return 'X';

    if (TABLE[0][1] =='X'&& TABLE[1][1] =='X'&& TABLE[2][1] =='X')//5
        return 'X';
    if (TABLE[0][2] =='X'&& TABLE[1][2] =='X'&& TABLE[2][2] =='X')//6
        return 'X';
    //diagonals for reference
    //00 01 02
    //10 11 12
    //20 21 22
    //diagonal wins for X
    if (TABLE[0][0] =='X'&& TABLE[1][1] =='X'&& TABLE[2][2] =='X')//7
        return 'X';
    if (TABLE[2][0] =='X'&& TABLE[1][1] =='X'&& TABLE[0][2] =='X')//8
        return 'X';

   //Win for O
    if (TABLE[0][0] =='O'&& TABLE[0][1] =='O'&& TABLE[0][2] =='O')//9
        return 'O';
    if (TABLE[1][0] =='O'&& TABLE[1][1] =='O'&& TABLE[1][2] =='O')//10
        return 'O';
    if (TABLE[2][0] =='O'&& TABLE[2][1] =='O'&& TABLE[2][2] =='O')//11
        return 'O';
    if (TABLE[0][0] =='O'&& TABLE[1][0] =='O'&& TABLE[2][0] =='O')//12
        return 'O';

    if (TABLE[0][1] =='O'&& TABLE[1][1] =='O'&& TABLE[2][1] =='O')//13
        return 'O';
    if (TABLE[0][2] =='O'&& TABLE[1][2] =='O'&& TABLE[2][2] =='O')//14
        return 'O';
    //diagonals for reference
    //00 01 02
    //10 11 12
    //20 21 22
    //diagonal wins for O
    if (TABLE[0][0] =='O'&& TABLE[1][1] =='O'&& TABLE[2][2] =='O')//15
        return 'O';
    if (TABLE[2][0] =='O'&& TABLE[1][1] =='O'&& TABLE[0][2] =='O')//16
        return 'O';
    return '/';//End of game! Project 2 Version 1
}
