/* 
 * Author: Marco Arias
 * Created on January 28, 2016, 08:27 AM
 * Purpose: Gross Pay
 * Midterm Problem 5
 */
 
//System Libraries
#include <iostream>
using namespace std;
 
//User Libraries
 
//Global Constant

//Function Prototypes
 
//Execution Begins Here
int main(int argc, char** argv) {
//Declare and initialize variables
    float pay,       //The amount user is being paid
          hours,     //The hours worked  
          tmeHlf=20, //Any time over 20 hours
          dblTme=40; //Any time over 40 hours  

//Input the value 
    cout<<"How much do you get paid per hour, in dollars?\n";//In $
    cin>>pay;
    cout<<"How many hours did you work this week?\n";//Hours worked this week
    cin>>hours;

//Calculation of amount &
//Output the results
    if(hours<=tmeHlf){
        cout<<"You've made $"<<pay*hours<<" this week\n";
    }else {if(hours>=dblTme){
        cout<<"You've made $"<<(pay*2)*hours<<" this week\n";
    }else {if(hours>=tmeHlf){
        cout<<"You've made $"<<(pay*1.5)*hours<<" this week\n";
      }
     }
    }

//Exit stage 
    return 0;
}