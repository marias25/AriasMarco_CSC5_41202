#include <iostream>

using namespace std;

 

//Execution begins here!

int main ()

 {

float lmpSum, aftrTax, mrried, jackPot, taxTtl, total; //Declare variables

 

lmpSum = .62f;

aftrTax = .52f;

mrried = .5f;

jackPot = 1.4e9f;

taxTtl = lmpSum*aftrTax*mrried;

total = jackPot*taxTtl;

cout<<"One would receive "<<total<<" if they won the jackpot of "<<jackPot<<" and if they were married, after taxes.\n";

	return 0;

}

