/* 
    File:   main.cpp
    Author: Marco Arias
    Created on January 24, 2016, 07:27 PM
    Purpose:  Sum Of Numbers
 */

//System Libraries
#include <iostream> //I/O

using namespace std;

//User Libraries

//Global Constants


//Function prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    const int MIN_NUMBER=1;//The minimum number
    int num, maxNmbr;//The number being squared
    
    //Display 
    cout<<"Enter a positive number and this program will display numbers leading"
            " up to that number\n";
    cin>>maxNmbr;
    cout<<"Here it is!\n";
    
    for(num=MIN_NUMBER;num<=maxNmbr;num++)
        cout<<num<<endl;
    
    
    //Set the numeric output formatting
    
    
    //Respond to the users menu selection
    
    //Respond
    
 //Exit stage right
    return 0;
}