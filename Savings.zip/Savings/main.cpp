/* 
    File:   main.cpp
    Author: Marco Arias
    Created on January 21, 2016, 08:20 AM
    Purpose:  Convert Arabic Numerals to Roman numerals
 */

//System Libraries
#include <iostream> //I/O
#include <iomanip>
#include <cstdlib>
using namespace std;

//User Libraries

//Global Constants


//Function prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //The problem to solve
    cout<<endl<<"Fun look at saving and rule 72"<<endl;
    cout<<endl<<"CA municipal Bonds"<<endl<<endl;
    
    //Declare and initialize variables 
    float balance=100.0f;       //Initial balance $'s
    float intRate=.05f;         //Interest rate / year
    float rule72=0.72f/intRate; //Rule of 72, Future Value=2*Present Value
    
    
    //Output table heading
    cout<<"The interest rate = "<<intRate*100<<"%"<<endl;
    cout<<"At this interest ratePrinciple should double every ";
    cout<<rule72<<" Years"<<endl;
    cout<<"  Year  Year  Balance  Interest";
    cout<<fixed<<setprecision(2)<<showpoint<<endl;
    cout<<"   0    2016"<<setw(8)<<balance<<setw(8)<<balance*intRate<<endl;
  
//Calculate the savings
    balance*=(1+intRate);
    for(int y=1,year=2017;y<=50;y++,year++){
        cout<<setw(4)<<y<<setw(8)<<year<<setw(8)<<balance<<setw(8)<<balance*intRate<<endl;
        balance*=(1+intRate);
    }
    
    //Output the number and its components
    
    
    //Output the results
    
    //output the 1000's
    
    
    //Output the 100's
   
    
            
            
            
 
    
    //Exit stage right
    return 0;
}


