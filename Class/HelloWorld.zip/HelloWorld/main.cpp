/* 
    File:   main.cpp
    Author: Marco Arias
    Created on January 4, 2016, 10:18 AM
    Purpose:  Check out IDE
 */

//System Libraries
#include <cstdlib>
using namespace std;

//User Libraries
 
 //Global Constants

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare and initialize variables
    
    //iNPUT data
    
    //Calculate o map inputs to outputs
    
    //Output the results
    
    //cout<<"HelloWorld"<<endl;
    //Exit stage right
    return 0;
}

