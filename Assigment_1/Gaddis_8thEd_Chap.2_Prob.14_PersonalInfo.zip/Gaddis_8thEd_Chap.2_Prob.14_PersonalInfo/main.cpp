
/* 
 * File:   Gaddis_8thEd_Chap.2_Prob.14_PersonalInfo
 * Author: Marco Arias
 *
 * Created on January 10, 2016, 10:05 PM
 */

#include <iostream>

using namespace std;

int main() 
{
    cout<<"Marco Arias \n";
    cout<<"32910 Rome Hill Rd., Lake Elsinore, CA 92530 \n";
    cout<<"951970039 \n";
    cout<<"Mechanical Engineering \n";

    return 0;
}

