/* 
 * File:   Gaddis_8thEd_Chap.2_Prob.4_Bill
 * Author: Marco Arias
 *
 * Created on January 10, 2016, 7:18 PM
 */

#include <iostream>

using namespace std;

int main() 

{
    float bill = 88.67;//the bill was 88.67.
    float tax = 1.0675;// the tax was 6.75%.
    float tip = 1.20;// the tip should be 20%.
    float taxTotal = bill*tax;
    float total = taxTotal*tip;
    
    cout<<"The total after having a meal of $88.67 turned out to be $",
    cout<<total<<endl;
    
    
    return 0;
}

