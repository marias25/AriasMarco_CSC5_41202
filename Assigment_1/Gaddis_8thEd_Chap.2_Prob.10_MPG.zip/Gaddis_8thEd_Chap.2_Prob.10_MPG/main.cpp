/* 
 * File:   Gaddis_8thEd_Chap.2_Prob.10_MPG
 * Author: Marco Arias
 *
 * Created on January 10, 2016, 9:26 PM
 */

#include <iostream>

using namespace std;

int main() 
{
    int gasTnk, drvRng, mpg;
    gasTnk = 15; //In gallons.
    drvRng = 375; //In miles.
    mpg = drvRng/gasTnk;//MPG.
    
    //Execution begins here.
    
cout<<"A car that holds "<<gasTnk<<" gallons and can drive"<<endl;
cout<<drvRng<<" miles gets "<<mpg<<" MPG.";

    return 0;
}

