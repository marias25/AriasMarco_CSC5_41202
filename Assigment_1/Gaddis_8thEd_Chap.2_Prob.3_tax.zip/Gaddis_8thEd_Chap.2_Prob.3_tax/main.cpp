/* 
 * File:   Gaddis_8thEd_Chap.2_Prob.3_tax
 * Author: Marco Arias
 *
 * Created on January 10, 2016, 1:58 PM
 */

#include <iostream>

using namespace std;

int main() 
{
    float sttTax = .04;
    float cntyTax = .02;
    float sale = 95;
    float total = sale * (cntyTax + sttTax);
    
    cout<<"The sale of $"<<sale<<" has a total tax of $"<<total<<endl;
    
    return 0;
}

