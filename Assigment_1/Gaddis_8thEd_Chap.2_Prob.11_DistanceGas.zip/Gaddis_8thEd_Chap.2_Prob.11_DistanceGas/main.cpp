/* 
 * File:   Gaddis_8thEd_Chap.2_Prob.11_DistanceGas
 * Author: Marco Arias
 *
 * Created on January 10, 2016, 9:51 PM
 */

#include <iostream>

using namespace std;

int main() 
{
    float gasTnk, ctyDrv, hwyDrv, ttlCty, ttlHwy;
     
    gasTnk = 20;
    ctyDrv = 23.5f;
    hwyDrv = 29.9f;
    ttlCty = gasTnk*ctyDrv;
    ttlHwy = gasTnk*hwyDrv;
    //Execution begins here.
    //This is the distance the car can go if it drives all city miles with
    //a full tank.
    cout<<"City driving with a full tank reaches "<<ttlCty<<" miles.\n";
    
    //This is distance if the car drives all highway.
    cout<<"Highway driving with a full tank reaches "<<ttlHwy<<" miles.\n";

    return 0;
}

