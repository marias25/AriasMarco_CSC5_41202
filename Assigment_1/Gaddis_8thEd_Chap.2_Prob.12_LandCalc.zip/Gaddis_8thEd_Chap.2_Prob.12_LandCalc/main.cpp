/* 
 * File:   Gaddis_8thEd_Chap.2_Prob.12_LandCalc
 * Author: Marco Arias
 *
 * Created on January 10, 2016, 10:12 PM
 */

#include <iostream>

using namespace std;

int main() 
{
    float acre, lndSze, ttlAcrs;
    
    acre = 43560; //In square feet.
    lndSze = 391876; //In square feet.
    ttlAcrs = lndSze/acre; //Gives the total number of acres for that land.
    
    //Execution begins here.
    cout<<"If a field has 391876 sq.ft., then it has ";
    cout<<ttlAcrs<<" acres of land. \n";
    
            
    
    
    return 0;
}

