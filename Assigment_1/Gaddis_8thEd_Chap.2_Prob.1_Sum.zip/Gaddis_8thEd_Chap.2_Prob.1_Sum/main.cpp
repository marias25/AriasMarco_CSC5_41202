/* 
 * File:   Gaddis_8thEd_Chap.2_Prob.1_Sum_1
 * Author: Marco Arias
 *
 * Created on January 9, 2016, 10:12 PM
 */

#include <iostream>

using namespace std;

int main() 
{ //Execution begins here
int fifty = 50, hndrd = 100, total = fifty+hndrd;


    cout<<fifty<<" + "<<hndrd<<" = "<<total<<endl;
    
    return 0;
}

