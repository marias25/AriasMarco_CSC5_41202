/* File: Gaddis_8thEd_Chap.2_Prob.2_sales
 * Author: Marco Arias
 *
 * Created on January 9, 2016, 10:54 PM
 */

#include <iostream>

using namespace std;

int main ()
{
    
//East Coast sales company made 8.6 million that year.
int ecCmpny = 8.6e6f;

//The division made 4.988 million that year.
int total = ecCmpny*.58;

// Display the results.
cout<<"The sales division of East Coast Company generates 58% \n";
cout<<"of total sales. If East Coast company makes $"<<ecCmpny<< " this year, \n";
cout<<"the sales division will have made $"<<total<<" for the East ";
cout<<"Coast Company."<<endl;

    return 0;
}

