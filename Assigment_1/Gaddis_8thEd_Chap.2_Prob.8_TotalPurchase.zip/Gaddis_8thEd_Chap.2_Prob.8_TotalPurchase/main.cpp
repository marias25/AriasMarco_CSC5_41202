
/* 
 * File:   Gaddis_8thEd_Chap.2_Prob.8_TotalPurchase
 * Author: Marco Arias
 *
 * Created on January 10, 2016, 8:40 PM
 */

#include <iostream>

using namespace std;

int main() 
{
    float priceItm1, priceItm2, priceItm3, priceItm4, priceItm5;
    //These items are in dollars ($).
    priceItm1 = 15.95f;
    priceItm2 = 24.95f;
    priceItm3 = 6.95f;
    priceItm4 = 12.95f;
    priceItm5 = 3.95f;
    float subTtl, tax, total;
    subTtl = priceItm1+priceItm2+priceItm3+priceItm4+priceItm5;
    tax = subTtl*.07f;//The tax is 7%.
    total = subTtl*1.07f;
    //Execution begins here.
    cout<<"The subtotal after buying 5 items is $";
    cout<<subTtl<<" and the tax is $"<<tax<<".";
    cout<<" The total sale comes out to $"<<total<<endl;
            
           

    return 0;
}

