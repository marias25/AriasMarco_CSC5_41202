/* 
 * File:   Gaddis_8thEd_Chap.2_Prob.6_AnnualPay
 * Author: Marco Arias
 *
 * Created on January 10, 2016, 8:26 PM
 */

#include <iostream>

using namespace std;
int main () 
{
    float payAmnt, payPrds, annlPay;
    payAmnt = 2200; //This is the amount paid every 2 week.
    
    payPrds = 26; //The amount of times they get paid per year.
    
    annlPay = payAmnt*payPrds;
    //Execution begins here.
    
    cout<<"This person gets paid $"<<payAmnt<<" every 2 weeks.";
    cout<<" They get paid "<<payPrds<<" times per year."<<endl;
    cout<<" Annually, they get paid $"<<annlPay<<endl;
            
            

    return 0;
}

