/* 
    File:   main.cpp
    Author: Marco Arias
    Created on January 21, 2016, 08:20 AM
    Purpose:  Convert Arabic Numerals to Roman numerals
 */

//System Libraries
#include <iostream> //I/O
#include <iomanip>
#include <cstdlib>
using namespace std;

//User Libraries

//Global Constants


//Function prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //The problem to solve
    cout<<endl<<"Fun look at Inflation"<<endl;
   
    //Declare and initialize variables 
    float balance=100.0f;       //Initial price $'s
    float inflate=.07f;         //Interest rate / year
    float rule72=0.72f/inflate; //Rule of 72, Future Value=2*Present Value
    float intErnd;              //Interest earned
    
    
    //Output table heading
    cout<<"The interest rate = "<<inflate*100<<"%"<<endl;
    cout<<"At this price the SubSandwhich should double every ";
    cout<<rule72<<" Years"<<endl;
    cout<<"  Year  Year  Balance  Interest";
    cout<<fixed<<setprecision(2)<<showpoint<<endl;
    
  
//Calculate the savings
    
    for (int y=0,year=2016;y<=50;y++,year++){
        intErnd=balance*inflate;
        cout<<setw(4)<<y<<setw(8)<<" "<<year<<setw(8)<<balance
                <<setw(8)<<intErnd<<endl;
        balance*=(1+inflate);
    }
    
    //Output the number and its components
    
    
    //Output the results
    
    //output the 1000's
    
    
    //Output the 100's
   
    
            
            
            
 
    
    //Exit stage right
    return 0;
}


